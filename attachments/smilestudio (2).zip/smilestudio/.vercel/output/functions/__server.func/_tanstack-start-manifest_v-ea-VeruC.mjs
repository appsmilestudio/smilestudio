//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-ea-VeruC.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/anghe/Downloads/smilestudio/src/routes/__root.tsx",
		children: ["/", "/c/$id"],
		preloads: ["/assets/index-21tEhbpB.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-21tEhbpB.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/anghe/Downloads/smilestudio/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D03Km171.js", "/assets/ui-Dc5eI_cT.js"]
	},
	"/c/$id": {
		filePath: "C:/Users/anghe/Downloads/smilestudio/src/routes/c.$id.tsx",
		children: void 0,
		preloads: ["/assets/c._id-M4SRaxas.js", "/assets/ui-Dc5eI_cT.js"]
	}
} });
//#endregion
export { tsrStartManifest };
