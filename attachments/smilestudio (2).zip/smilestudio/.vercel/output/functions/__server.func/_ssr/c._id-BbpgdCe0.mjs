import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ArrowLeft, s as Stethoscope, v as CircleCheck, w as Calendar } from "../_libs/lucide-react.mjs";
import { n as Route } from "./router-B0OXP2Eg.mjs";
import { b as formatTime, g as doctorById, t as Btn, v as formatDay, z as useSmileStore } from "./ui-DoLSHGFS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/c._id-BbpgdCe0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ConfirmPage() {
	const { id } = Route.useParams();
	const [ready, setReady] = (0, import_react.useState)(false);
	const visit = useSmileStore((state) => state.visits.find((item) => item.id === id));
	const patient = useSmileStore((state) => state.patients.find((item) => item.id === visit?.patientId));
	const moveVisit = useSmileStore((state) => state.moveVisit);
	const [done, setDone] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		Promise.resolve(useSmileStore.persist.rehydrate()).finally(() => setReady(true));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen max-w-md flex-col justify-center px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/clinic-logo.png",
					alt: "Smile Studio",
					className: "mark-in mx-auto h-32 w-auto object-contain sm:h-40"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs font-semibold tracking-wider uppercase text-gold-deep",
					children: "Piura, Perú"
				})]
			}),
			!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 text-center text-sm text-muted animate-pulse",
				children: "Cargando tu cita…"
			}) : null,
			ready && (!visit || !patient) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise mt-8 rounded-2xl border border-line bg-paper p-6 text-center shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-base font-medium text-ink",
					children: "Cita no encontrada"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Este enlace no corresponde a una cita vigente en este dispositivo."
				})]
			}) : null,
			ready && visit && patient ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise mt-6 overflow-hidden rounded-3xl border border-line bg-paper p-6 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-b border-line pb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium uppercase tracking-wider text-muted",
							children: "Paciente"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 font-display text-3xl font-semibold leading-tight text-ink",
							children: patient.fullName
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 text-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-4 shrink-0 text-gold-deep" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-medium",
									children: [formatDay(visit.date), visit.time ? ` · ${formatTime(visit.time)}` : ""]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stethoscope, { className: "size-4 shrink-0 text-gold-deep" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									doctorById(visit.doctorId).short,
									" (",
									doctorById(visit.doctorId).name,
									")"
								] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-cream/70 p-3 text-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted block mb-0.5",
									children: "Tratamiento o motivo:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: visit.treatment
								})]
							})
						]
					}),
					done === "confirmada" || visit.status === "confirmada" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rise mt-5 flex items-center gap-2.5 rounded-2xl bg-moss-soft p-4 text-sm font-medium text-moss",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "¡Cita confirmada! Te esperamos con gusto en Smile Studio." })]
					}) : null,
					done === "reprogramada" || visit.status === "reprogramada" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rise mt-5 rounded-2xl bg-gold-soft p-4 text-sm font-medium text-gold-deep",
						children: "Solicitud recibida. Recepción se comunicará contigo por WhatsApp para coordinar otro horario."
					}) : null,
					visit.status !== "confirmada" && visit.status !== "reprogramada" && visit.status !== "cancelada" && !done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 space-y-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							full: true,
							tone: "moss",
							onClick: () => {
								moveVisit(visit.id, { status: "confirmada" });
								setDone("confirmada");
							},
							children: "Confirmo que voy"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							full: true,
							tone: "paper",
							onClick: () => {
								moveVisit(visit.id, { status: "reprogramada" });
								setDone("reprogramada");
							},
							children: "Quiero otra hora"
						})]
					}) : null
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex items-center gap-1.5 text-sm font-medium text-gold-deep hover:underline",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Volver a Smile Studio"]
				})
			})
		]
	});
}
//#endregion
export { ConfirmPage as component };
