import { o as __toESM } from "../_runtime.mjs";
import { d as require_react_dom, q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, i as Printer, n as Trash2, o as Download, r as Search } from "../_libs/lucide-react.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DBs0jRq1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = require_react_dom();
var TABS = [
	{
		id: "odontograma",
		label: "Odontograma",
		blurb: "Piezas superiores e inferiores, simbología y plan corto."
	},
	{
		id: "ficha",
		label: "Ficha clínica",
		blurb: "Datos, antecedentes, próximas citas y esquema."
	},
	{
		id: "plan",
		label: "Plan de tratamiento",
		blurb: "Presupuesto, evolución, pagos y saldo."
	},
	{
		id: "ortodoncia",
		label: "Control de ortodoncia",
		blurb: "Instalación, controles y cuota mensual."
	}
];
var UPPER = [
	"18",
	"17",
	"16",
	"15",
	"14",
	"13",
	"12",
	"11",
	"21",
	"22",
	"23",
	"24",
	"25",
	"26",
	"27",
	"28"
];
var LOWER = [
	"48",
	"47",
	"46",
	"45",
	"44",
	"43",
	"42",
	"41",
	"31",
	"32",
	"33",
	"34",
	"35",
	"36",
	"37",
	"38"
];
var LEGEND = [
	{
		id: "sano",
		label: "Sano",
		swatch: "fill"
	},
	{
		id: "caries",
		label: "Caries",
		swatch: "fill"
	},
	{
		id: "obturacion",
		label: "Obturación",
		swatch: "fill"
	},
	{
		id: "corona",
		label: "Corona",
		swatch: "fill"
	},
	{
		id: "extraccion",
		label: "Extracción indicada",
		swatch: "x"
	},
	{
		id: "ausente",
		label: "Ausente",
		swatch: "empty"
	},
	{
		id: "endodoncia",
		label: "Endodoncia",
		swatch: "fill"
	},
	{
		id: "protesis-fija",
		label: "Prótesis fija",
		swatch: "fill"
	},
	{
		id: "protesis-removible",
		label: "Prótesis removible",
		swatch: "fill"
	},
	{
		id: "sellante",
		label: "Sellante",
		swatch: "fill"
	},
	{
		id: "fractura",
		label: "Fractura",
		swatch: "crack"
	}
];
var SURFACE_TOOLS = [
	"sano",
	"caries",
	"obturacion",
	"sellante"
];
var EMPTY_TOOTH = {
	surfaces: {},
	whole: ""
};
var ANTE_BLANK = {
	alergias: "",
	diabetes: "",
	cardiovascular: "",
	hemorragias: "",
	gestante: "",
	hipertension: "",
	renal: "",
	otra: ""
};
function todaySlash() {
	const d = /* @__PURE__ */ new Date();
	const p = (n) => String(n).padStart(2, "0");
	return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}`;
}
function ageFrom(fecha) {
	const m = fecha.trim().match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
	if (!m) return null;
	const day = Number(m[1]);
	const month = Number(m[2]);
	const year = Number(m[3]);
	const born = new Date(year, month - 1, day);
	if (born.getFullYear() !== year || born.getMonth() !== month - 1 || born.getDate() !== day) return null;
	const now = /* @__PURE__ */ new Date();
	let age = now.getFullYear() - year;
	const md = now.getMonth() - (month - 1);
	if (md < 0 || md === 0 && now.getDate() < day) age -= 1;
	if (age < 0 || age > 120) return null;
	return String(age);
}
function list(n, make) {
	return Array.from({ length: n }, make);
}
function blankCita() {
	return {
		fecha: "",
		hora: ""
	};
}
function blankPresupuesto() {
	return {
		concepto: "",
		unit: "",
		total: ""
	};
}
function blankEvolucion() {
	return {
		fecha: "",
		tratamiento: "",
		saldo: "",
		pago: ""
	};
}
function blankPlan() {
	return {
		fecha: "",
		tratamiento: "",
		pago: "",
		saldo: ""
	};
}
function blankControl() {
	return {
		fecha: "",
		nro: "",
		tratamiento: "",
		pago: ""
	};
}
function blankPatient(id, odontologo = "") {
	return {
		id,
		apellidos: "",
		nombres: "",
		nombreCompleto: "",
		edad: "",
		dni: "",
		odontologo,
		fecha: todaySlash(),
		telefono: "",
		direccion: "",
		fechaNac: "",
		teeth: {},
		observacionesOdonto: "",
		planOdonto: [
			"",
			"",
			"",
			"",
			""
		],
		antecedentes: { ...ANTE_BLANK },
		otraDetalle: "",
		motivo: "",
		medicamento: "",
		examen: "",
		observacionesHistoria: "",
		citas: list(18, blankCita),
		arch: {},
		presupuesto: list(8, blankPresupuesto),
		evolucion: list(10, blankEvolucion),
		planRows: list(12, blankPlan),
		cuotaMensual: "",
		fechaSup: "",
		fechaInf: "",
		controles: list(14, blankControl)
	};
}
function patientLabel(p) {
	const full = p.nombreCompleto.trim();
	if (full) return full;
	return `${p.apellidos} ${p.nombres}`.trim() || "Paciente sin nombre";
}
function toothKind(fdi) {
	const n = Number(fdi) % 10;
	if (n >= 6) return "molar";
	if (n >= 4) return "premolar";
	if (n === 3) return "canine";
	if (n === 2) return "lateral";
	return "central";
}
function isUpper(fdi) {
	return fdi.startsWith("1") || fdi.startsWith("2");
}
/** Mesial side sits on the right of the cell for the patient's right quadrants. */
function mesialOnRight(fdi) {
	const q = fdi[0];
	return q === "1" || q === "4";
}
function isWholeTool(tool) {
	return !SURFACE_TOOLS.includes(tool);
}
function markColor(mark) {
	switch (mark) {
		case "caries": return "var(--color-caries)";
		case "obturacion": return "var(--color-obt)";
		case "corona": return "var(--color-corona)";
		case "endodoncia": return "var(--color-endo)";
		case "protesis-fija": return "var(--color-fija)";
		case "protesis-removible": return "var(--color-remov)";
		case "sellante": return "var(--color-sellante)";
		case "fractura": return "var(--color-fractura)";
		default: return "transparent";
	}
}
function dominantMark(tooth) {
	if (tooth.whole) return tooth.whole;
	const order = [
		"caries",
		"obturacion",
		"sellante"
	];
	const values = Object.values(tooth.surfaces);
	for (const mark of order) if (values.includes(mark)) return mark;
	return "";
}
var FDI_TO_UNI = {};
[
	"18",
	"17",
	"16",
	"15",
	"14",
	"13",
	"12",
	"11"
].forEach((fdi, i) => {
	FDI_TO_UNI[fdi] = String(i + 1);
});
[
	"21",
	"22",
	"23",
	"24",
	"25",
	"26",
	"27",
	"28"
].forEach((fdi, i) => {
	FDI_TO_UNI[fdi] = String(i + 9);
});
[
	"31",
	"32",
	"33",
	"34",
	"35",
	"36",
	"37",
	"38"
].forEach((fdi, i) => {
	FDI_TO_UNI[fdi] = String(24 - i);
});
[
	"41",
	"42",
	"43",
	"44",
	"45",
	"46",
	"47",
	"48"
].forEach((fdi, i) => {
	FDI_TO_UNI[fdi] = String(25 + i);
});
function archFromTeeth(teeth) {
	const arch = {};
	for (const [fdi, uni] of Object.entries(FDI_TO_UNI)) arch[`u${uni}`] = dominantMark(teeth[fdi] ?? EMPTY_TOOTH);
	return arch;
}
function archNodes() {
	const nodes = [];
	const cx = 320;
	const cy = 248;
	[
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7",
		"8",
		"9",
		"10",
		"11",
		"12",
		"13",
		"14",
		"15",
		"16",
		"17",
		"18",
		"19",
		"20",
		"21",
		"22",
		"23",
		"24",
		"25",
		"26",
		"27",
		"28",
		"29",
		"30",
		"31",
		"32"
	].forEach((label, i) => {
		const a = Math.PI - i / 32 * Math.PI * 2;
		nodes.push({
			id: `u${label}`,
			label,
			x: cx + Math.cos(a) * 214,
			y: cy - Math.sin(a) * 168,
			r: 14
		});
	});
	[
		"A",
		"B",
		"C",
		"D",
		"E",
		"F",
		"G",
		"H",
		"I",
		"J"
	].forEach((label, i) => {
		const a = Math.PI * .86 - i / 9 * Math.PI * .72;
		nodes.push({
			id: `p${label}`,
			label,
			x: cx + Math.cos(a) * 132,
			y: cy - Math.sin(a) * 104,
			r: 10
		});
	});
	[
		"T",
		"S",
		"R",
		"Q",
		"P",
		"O",
		"N",
		"M",
		"L",
		"K"
	].forEach((label, i) => {
		const a = Math.PI * 1.14 + i / 9 * Math.PI * .72;
		nodes.push({
			id: `p${label}`,
			label,
			x: cx + Math.cos(a) * 132,
			y: cy - Math.sin(a) * 104,
			r: 10
		});
	});
	return nodes;
}
function parseMoney(value) {
	const raw = value.replace(/s\/?\s*/i, "").replace(/\s/g, "");
	if (!raw) return 0;
	const cleaned = raw.replace(/[^\d,.-]/g, "");
	let normalized = cleaned;
	if (cleaned.includes(",") && cleaned.includes(".")) normalized = cleaned.lastIndexOf(",") > cleaned.lastIndexOf(".") ? cleaned.replace(/\./g, "").replace(",", ".") : cleaned.replace(/,/g, "");
	else normalized = cleaned.replace(",", ".");
	const n = Number(normalized);
	return Number.isFinite(n) ? n : 0;
}
function formatSoles(n) {
	return `S/ ${n.toLocaleString("es-PE", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	})}`;
}
function sumMoney(values) {
	return values.reduce((acc, value) => acc + parseMoney(value), 0);
}
function commitRow(rows, index, next, isEmpty, blank) {
	const copy = rows.map((row, i) => i === index ? next : row);
	const last = copy[copy.length - 1];
	if (last && !isEmpty(last) && copy.length < 40) copy.push(blank);
	return copy;
}
function crownPath(kind) {
	switch (kind) {
		case "molar": return {
			body: "M7 11c0-5 34-5 34 0l2 14c2 12-5 22-11 25-4 2-6-4-8-4s-4 6-8 4C10 47 3 37 5 25Z",
			grooves: "M15 22h18M24 18v24M13 32h22"
		};
		case "premolar": return {
			body: "M11 11h26c4 0 6 8 4 18-4 16-10 20-17 20S11 45 7 29C5 19 7 11 11 11Z",
			grooves: "M24 18v26M14 30h20"
		};
		case "canine": return {
			body: "M15 11h18l2 16L24 52 13 27Z",
			grooves: "M24 16v24"
		};
		case "lateral": return {
			body: "M17 10h14l2 18-9 22-9-22Z",
			grooves: "M24 16v22"
		};
		default: return {
			body: "M13 10h22l2 20-13 20L11 30Z",
			grooves: "M24 16v22"
		};
	}
}
function isPresupuestoEmpty(row) {
	return !row.concepto && !row.unit && !row.total;
}
function isEvolucionEmpty(row) {
	return !row.fecha && !row.tratamiento && !row.saldo && !row.pago;
}
function isPlanEmpty(row) {
	return !row.fecha && !row.tratamiento && !row.pago && !row.saldo;
}
function isControlEmpty(row) {
	return !row.fecha && !row.nro && !row.tratamiento && !row.pago;
}
function paintTooth(prev, tool, target) {
	const next = {
		whole: prev.whole,
		surfaces: { ...prev.surfaces }
	};
	if (target === "crown") {
		if (tool === "sano") {
			next.whole = "";
			next.surfaces = {};
			return next;
		}
		if (isWholeTool(tool)) {
			next.whole = tool;
			return next;
		}
		for (const face of [
			"v",
			"m",
			"d",
			"l",
			"o"
		]) next.surfaces[face] = tool;
		return next;
	}
	if (tool === "sano") {
		delete next.surfaces[target];
		return next;
	}
	if (isWholeTool(tool)) {
		next.whole = tool;
		return next;
	}
	next.surfaces[target] = tool;
	return next;
}
var useClinic = create()(persist((set, get) => ({
	hydrated: false,
	tab: "odontograma",
	tool: "caries",
	activeId: null,
	lastOdontologo: "",
	patients: [],
	setHydrated: () => set({ hydrated: true }),
	setTab: (tab) => set({ tab }),
	setTool: (tool) => set({ tool }),
	setActive: (activeId) => set({ activeId }),
	addPatient: (tab) => {
		const id = crypto.randomUUID();
		const patient = blankPatient(id, get().lastOdontologo);
		set((s) => ({
			patients: [patient, ...s.patients],
			activeId: id,
			tab: tab ?? s.tab
		}));
		return id;
	},
	removePatient: (id) => set((s) => {
		const patients = s.patients.filter((p) => p.id !== id);
		return {
			patients,
			activeId: s.activeId === id ? patients[0]?.id ?? null : s.activeId
		};
	}),
	edit: (id, recipe) => set((s) => {
		const patients = s.patients.map((p) => p.id === id ? recipe(p) : p);
		const next = patients.find((p) => p.id === id);
		return {
			patients,
			lastOdontologo: next?.odontologo ? next.odontologo : s.lastOdontologo
		};
	}),
	applyTooth: (id, fdi, tool, target) => set((s) => ({ patients: s.patients.map((p) => {
		if (p.id !== id) return p;
		const prev = p.teeth[fdi] ?? EMPTY_TOOTH;
		return {
			...p,
			teeth: {
				...p.teeth,
				[fdi]: paintTooth(prev, tool, target)
			}
		};
	}) })),
	applyArch: (id, key, tool) => set((s) => ({ patients: s.patients.map((p) => {
		if (p.id !== id) return p;
		const arch = { ...p.arch };
		if (tool === "sano") delete arch[key];
		else arch[key] = tool;
		return {
			...p,
			arch
		};
	}) })),
	copyArch: (id) => set((s) => ({ patients: s.patients.map((p) => {
		if (p.id !== id) return p;
		const brought = archFromTeeth(p.teeth);
		const arch = { ...p.arch };
		for (const [key, mark] of Object.entries(brought)) if (mark) arch[key] = mark;
		else delete arch[key];
		return {
			...p,
			arch
		};
	}) })),
	importPatients: (rows) => set((s) => {
		const map = new Map(s.patients.map((p) => [p.id, p]));
		for (const row of rows) map.set(row.id, row);
		const patients = [...map.values()];
		return {
			patients,
			activeId: s.activeId ?? patients[0]?.id ?? null
		};
	})
}), {
	name: "smile-studio-fichas-v1",
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? {
		getItem: () => null,
		setItem: () => {},
		removeItem: () => {}
	} : localStorage),
	partialize: (s) => ({
		tab: s.tab,
		activeId: s.activeId,
		lastOdontologo: s.lastOdontologo,
		patients: s.patients
	})
}));
function PaperLine({ label, value, onChange, id, placeholder, inputMode }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "paper-line",
		htmlFor: id,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id,
			className: "paper-input",
			value,
			placeholder,
			inputMode,
			onChange: (event) => onChange(event.target.value)
		})]
	});
}
function RuledArea({ label, value, onChange, rows = 3 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "paper-label",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			className: "ruled",
			rows,
			value,
			onChange: (event) => onChange(event.target.value)
		})]
	});
}
function YesNoField({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "yesno",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "yesno-opts",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				pressed: value === "si",
				onClick: () => onChange(value === "si" ? "" : "si"),
				children: "Sí"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				pressed: value === "no",
				onClick: () => onChange(value === "no" ? "" : "no"),
				children: "No"
			})]
		})]
	});
}
function Choice({ pressed, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "choice",
		"aria-pressed": pressed,
		onClick,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "choice-box" }), children]
	});
}
function Cell({ value, onChange, label, inputMode }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: "cell-input",
		value,
		"aria-label": label,
		inputMode,
		onChange: (event) => onChange(event.target.value)
	});
}
function StudioLogo({ className = "studio-logo" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: "/smile-studio-logo.png",
		alt: "Smile Studio. Cuidamos tu sonrisa, cuidamos de ti.",
		className
	});
}
function MarkImg({ className = "mark-img" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: "/smile-mark.png",
		alt: "",
		className
	});
}
function Swatch({ tool }) {
	const item = LEGEND.find((entry) => entry.id === tool);
	const color = tool === "sano" ? "var(--color-paper)" : markColor(tool);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "swatch",
		style: {
			background: color,
			borderColor: tool === "sano" ? "var(--color-line)" : color
		},
		"aria-hidden": true,
		children: [
			item?.swatch === "x" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "swatch-x" }) : null,
			item?.swatch === "empty" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "swatch-empty" }) : null,
			item?.swatch === "crack" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				viewBox: "0 0 16 16",
				className: "h-3 w-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M6 1.5 8.2 6H6.4L10.5 14.5 8 8.2h2.2L6 1.5Z",
					fill: "var(--color-fractura)"
				})
			}) : null
		]
	});
}
function LegendList({ tool, onTool, wrap = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "legend-box",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Simbología" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: wrap ? "legend-list wrap" : "legend-list",
			children: LEGEND.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "legend-btn",
				"aria-pressed": tool === item.id,
				onClick: () => onTool(item.id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, { tool: item.id }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
			}, item.id))
		})]
	});
}
function Diamond() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 10 10",
		className: "h-2.5 w-2.5 text-gold",
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M5 0 10 5 5 10 0 5Z",
			fill: "currentColor"
		})
	});
}
function GoldFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "gold-footer",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "gold-footer-item",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneIcon, {}), "949 390 316"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "gold-footer-item",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinIcon, {}), "Av. Grau 877 · Piura"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "gold-footer-item",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/smile-mark.png",
					alt: "",
					className: "footer-mark"
				}), "Tu sonrisa, nuestra pasión"]
			})
		]
	});
}
function PhoneIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: "h-4 w-4",
		fill: "none",
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M8 4h2.5l1.2 3-1.6 1.2a12 12 0 0 0 5.7 5.7L17 12.3 20 13.5V16a2 2 0 0 1-2.2 2A16 16 0 0 1 6 6.2 2 2 0 0 1 8 4Z",
			stroke: "currentColor",
			strokeWidth: "1.7",
			strokeLinejoin: "round"
		})
	});
}
function PinIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className: "h-4 w-4",
		fill: "none",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M12 21s6-5.2 6-10a6 6 0 1 0-12 0c0 4.8 6 10 6 10Z",
			stroke: "currentColor",
			strokeWidth: "1.7"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "12",
			cy: "11",
			r: "2",
			stroke: "currentColor",
			strokeWidth: "1.7"
		})]
	});
}
var ANTE = [
	{
		key: "alergias",
		label: "Alergias"
	},
	{
		key: "hemorragias",
		label: "Hemorragias"
	},
	{
		key: "diabetes",
		label: "Diabetes"
	},
	{
		key: "gestante",
		label: "Gestante"
	},
	{
		key: "cardiovascular",
		label: "Enf. cardiovascular"
	},
	{
		key: "hipertension",
		label: "Hipertensión"
	},
	{
		key: "renal",
		label: "Enfermedad renal"
	},
	{
		key: "otra",
		label: "Otra enfermedad"
	}
];
function FichaSheet({ patient, tool, onTool, onEdit, onArch, onCopy }) {
	const nodes = archNodes();
	const setAnte = (key, value) => onEdit((p) => ({
		...p,
		antecedentes: {
			...p.antecedentes,
			[key]: value
		}
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "sheet",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "ficha-mast",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/smile-banner.png",
					alt: "Smile Studio Centro Odontológico",
					className: "ficha-banner"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mast-address",
					children: [
						"Av. Grau 877, Piura",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"Centro de consultas (Sótano)",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"Tel. 949 390 316 · 961 617 933"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "historia-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stack",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
							label: "Paciente:",
							value: patient.nombreCompleto,
							onChange: (nombreCompleto) => onEdit((p) => ({
								...p,
								nombreCompleto
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "split-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
								label: "Apellidos:",
								value: patient.apellidos,
								onChange: (apellidos) => onEdit((p) => ({
									...p,
									apellidos,
									nombreCompleto: p.nombreCompleto.trim() ? p.nombreCompleto : `${apellidos} ${p.nombres}`.trim()
								}))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
								label: "Nombres:",
								value: patient.nombres,
								onChange: (nombres) => onEdit((p) => ({
									...p,
									nombres,
									nombreCompleto: p.nombreCompleto.trim() ? p.nombreCompleto : `${p.apellidos} ${nombres}`.trim()
								}))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
							label: "Dirección:",
							value: patient.direccion,
							onChange: (direccion) => onEdit((p) => ({
								...p,
								direccion
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "split-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
								label: "DNI:",
								value: patient.dni,
								inputMode: "numeric",
								onChange: (dni) => onEdit((p) => ({
									...p,
									dni
								}))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
								label: "Teléfono:",
								value: patient.telefono,
								inputMode: "tel",
								onChange: (telefono) => onEdit((p) => ({
									...p,
									telefono
								}))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "split-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
									label: "Fecha:",
									value: patient.fecha,
									placeholder: "dd/mm/aaaa",
									onChange: (fecha) => onEdit((p) => ({
										...p,
										fecha
									}))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
									label: "Fecha nac.:",
									value: patient.fechaNac,
									placeholder: "dd/mm/aaaa",
									onChange: (fechaNac) => onEdit((p) => ({
										...p,
										fechaNac,
										edad: ageFrom(fechaNac) ?? p.edad
									}))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
									label: "Edad:",
									value: patient.edad,
									inputMode: "numeric",
									onChange: (edad) => onEdit((p) => ({
										...p,
										edad
									}))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "boxed",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Antecedentes" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "ante-grid",
									children: ANTE.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(YesNoField, {
										label: item.label,
										value: patient.antecedentes[item.key],
										onChange: (value) => setAnte(item.key, value)
									}, item.key))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
									label: "Detalle:",
									value: patient.otraDetalle,
									onChange: (otraDetalle) => onEdit((p) => ({
										...p,
										otraDetalle
									}))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuledArea, {
							label: "Motivo de la consulta:",
							value: patient.motivo,
							rows: 2,
							onChange: (motivo) => onEdit((p) => ({
								...p,
								motivo
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuledArea, {
							label: "Está tomando algún medicamento:",
							value: patient.medicamento,
							rows: 2,
							onChange: (medicamento) => onEdit((p) => ({
								...p,
								medicamento
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuledArea, {
							label: "Examen clínico general:",
							value: patient.examen,
							rows: 2,
							onChange: (examen) => onEdit((p) => ({
								...p,
								examen
							}))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stack",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "boxed",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Próximas citas" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "teeth-scroll",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "grid-table citas-table",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
									"Fecha",
									"Hora",
									"Fecha",
									"Hora",
									"Fecha",
									"Hora"
								].map((label, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: label }, index)) }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: Array.from({ length: Math.ceil(patient.citas.length / 3) }, (_, row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
									0,
									1,
									2
								].map((col) => {
									const index = row * 3 + col;
									const cita = patient.citas[index];
									if (!cita) return null;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CitaPair, {
										fecha: cita.fecha,
										hora: cita.hora,
										onFecha: (fecha) => onEdit((p) => ({
											...p,
											citas: p.citas.map((item, i) => i === index ? {
												...item,
												fecha
											} : item)
										})),
										onHora: (hora) => onEdit((p) => ({
											...p,
											citas: p.citas.map((item, i) => i === index ? {
												...item,
												hora
											} : item)
										}))
									}, col);
								}) }, row)) })]
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "boxed",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "section-head",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Esquema dental" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-btn no-print",
									onClick: onCopy,
									children: "Traer del odontograma"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "no-print hint",
								children: "Derecha del paciente a la izquierda del esquema. Números permanentes, letras de leche."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegendList, {
								tool,
								onTool,
								wrap: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "teeth-scroll arch-scroll",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "arch-board",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
										viewBox: "0 0 640 500",
										className: "arch-guides",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
												cx: "320",
												cy: "248",
												rx: "214",
												ry: "168"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
												cx: "320",
												cy: "248",
												rx: "132",
												ry: "104"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
												x: "320",
												y: "214",
												textAnchor: "middle",
												children: "PALATINO"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
												x: "320",
												y: "292",
												textAnchor: "middle",
												children: "LINGUAL"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
												x: "78",
												y: "252",
												textAnchor: "middle",
												children: "DERECHA"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
												x: "562",
												y: "252",
												textAnchor: "middle",
												children: "IZQUIERDA"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
												transform: "rotate(-90 36 248)",
												x: "36",
												y: "248",
												textAnchor: "middle",
												children: "VESTIBULAR"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
												transform: "rotate(90 604 248)",
												x: "604",
												y: "248",
												textAnchor: "middle",
												children: "VESTIBULAR"
											})
										]
									}), nodes.map((node) => {
										const mark = patient.arch[node.id] ?? "";
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: `arch-node ${mark === "extraccion" ? "arch-x" : ""} ${mark === "ausente" ? "arch-absent" : ""}`,
											style: {
												left: `${node.x / 640 * 100}%`,
												top: `${node.y / 500 * 100}%`,
												width: `${node.r * 2 / 640 * 100}%`,
												height: `${node.r * 2 / 500 * 100}%`,
												backgroundColor: mark ? `color-mix(in srgb, ${markColor(mark)} 78%, white)` : "var(--color-paper)",
												borderColor: mark ? markColor(mark) : "var(--color-line)"
											},
											"aria-label": `Pieza ${node.label}`,
											onClick: () => onArch(node.id),
											children: node.label
										}, node.id);
									})]
								})
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuledArea, {
				label: "Observaciones:",
				value: patient.observacionesHistoria,
				rows: 4,
				onChange: (observacionesHistoria) => onEdit((p) => ({
					...p,
					observacionesHistoria
				}))
			})
		]
	});
}
function CitaPair({ fecha, hora, onFecha, onHora }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
		value: fecha,
		onChange: onFecha,
		label: "Fecha de cita"
	}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
		value: hora,
		onChange: onHora,
		label: "Hora de cita"
	}) })] });
}
function OdontogramaSheet({ patient, tool, onTool, onEdit, onTooth }) {
	const toolLabel = LEGEND.find((item) => item.id === tool)?.label ?? "Sano";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "sheet",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "odonto-layout",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "odonto-side",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "brand-lockup",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioLogo, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegendList, {
						tool,
						onTool
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "no-print hint",
						children: "Elige un símbolo. En caries, obturación o sellante toca una cara; en el resto, toca la corona. Sano borra."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: "mouth-quote",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkImg, { className: "mark-img sm" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", { children: ["Una boca sana es el reflejo de una ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "vida saludable." })] })]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "odonto-main",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "identity-grid",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
								id: "field-paciente",
								label: "Paciente:",
								value: patient.nombreCompleto,
								placeholder: `${patient.apellidos} ${patient.nombres}`.trim(),
								onChange: (nombreCompleto) => onEdit((p) => ({
									...p,
									nombreCompleto
								}))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "split-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
									label: "Edad:",
									value: patient.edad,
									inputMode: "numeric",
									onChange: (edad) => onEdit((p) => ({
										...p,
										edad
									}))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
									label: "DNI:",
									value: patient.dni,
									inputMode: "numeric",
									onChange: (dni) => onEdit((p) => ({
										...p,
										dni
									}))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
								label: "Odontólogo(a):",
								value: patient.odontologo,
								onChange: (odontologo) => onEdit((p) => ({
									...p,
									odontologo
								}))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "split-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
									label: "Fecha:",
									value: patient.fecha,
									placeholder: "dd/mm/aaaa",
									onChange: (fecha) => onEdit((p) => ({
										...p,
										fecha
									}))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
									label: "Teléfono:",
									value: patient.telefono,
									inputMode: "tel",
									onChange: (telefono) => onEdit((p) => ({
										...p,
										telefono
									}))
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "chart-title",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Diamond, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Odontograma" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Diamond, {})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "no-print marking",
						children: ["Marcando: ", toolLabel]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArchBlock, {
						title: "Superior",
						ids: UPPER,
						numbers: "top",
						patient,
						onTooth
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArchBlock, {
						title: "Inferior",
						ids: LOWER,
						numbers: "bottom",
						patient,
						onTooth
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "notes-grid",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuledArea, {
							label: "Observaciones:",
							value: patient.observacionesOdonto,
							rows: 5,
							onChange: (observacionesOdonto) => onEdit((p) => ({
								...p,
								observacionesOdonto
							}))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "paper-label",
							children: "Plan de tratamiento:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "plan-lines",
							children: patient.planOdonto.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [index + 1, "."] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "paper-input",
								value: line,
								"aria-label": `Plan ${index + 1}`,
								onChange: (event) => {
									const value = event.target.value;
									onEdit((p) => {
										const planOdonto = [...p.planOdonto];
										planOdonto[index] = value;
										return {
											...p,
											planOdonto
										};
									});
								}
							})] }, index))
						})] })]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldFooter, {})]
	});
}
function ArchBlock({ title, ids, numbers, patient, onTooth }) {
	const upper = numbers === "top";
	const occlusal = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "teeth-row",
		children: [
			ids.slice(0, 8).map((fdi) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToothColumn, {
				fdi,
				tooth: patient.teeth[fdi] ?? EMPTY_TOOTH,
				show: "occlusal",
				onTooth
			}, fdi)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "midline" }),
			ids.slice(8).map((fdi) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToothColumn, {
				fdi,
				tooth: patient.teeth[fdi] ?? EMPTY_TOOTH,
				show: "occlusal",
				onTooth
			}, fdi))
		]
	});
	const crowns = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "teeth-row",
		children: [
			ids.slice(0, 8).map((fdi) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToothColumn, {
				fdi,
				tooth: patient.teeth[fdi] ?? EMPTY_TOOTH,
				show: "crown",
				onTooth
			}, `${fdi}-c`)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "midline" }),
			ids.slice(8).map((fdi) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToothColumn, {
				fdi,
				tooth: patient.teeth[fdi] ?? EMPTY_TOOTH,
				show: "crown",
				onTooth
			}, `${fdi}-c`))
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "arch-block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "teeth-scroll",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "teeth-stack",
				children: [
					upper ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberRow, { ids }) : null,
					upper ? occlusal : crowns,
					upper ? crowns : occlusal,
					upper ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberRow, { ids })
				]
			})
		})]
	});
}
function NumberRow({ ids }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "teeth-row numbers",
		children: [
			ids.slice(0, 8).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: id }, id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
			ids.slice(8).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: id }, id))
		]
	});
}
function ToothColumn({ fdi, tooth, show, onTooth }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "tooth",
		children: show === "occlusal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Occlusal, {
			fdi,
			tooth,
			onTooth
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, {
			fdi,
			tooth,
			onTooth
		})
	});
}
function Occlusal({ fdi, tooth, onTooth }) {
	const vestTop = isUpper(fdi);
	const mesialRight = mesialOnRight(fdi);
	const zones = [
		{
			id: vestTop ? "v" : "l",
			points: "2,2 38,2 27,15 13,15"
		},
		{
			id: mesialRight ? "m" : "d",
			points: "38,2 38,42 27,29 27,15"
		},
		{
			id: vestTop ? "l" : "v",
			points: "2,42 13,29 27,29 38,42"
		},
		{
			id: mesialRight ? "d" : "m",
			points: "2,2 13,15 13,29 2,42"
		},
		{
			id: "o",
			points: "13,15 27,15 27,29 13,29"
		}
	];
	const absent = tooth.whole === "ausente";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 40 44",
		className: "tooth-svg",
		children: [
			zones.map((zone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: zone.points,
				className: "face",
				style: { fill: absent ? "transparent" : tooth.surfaces[zone.id] ? markColor(tooth.surfaces[zone.id]) : "var(--color-paper)" },
				strokeDasharray: absent ? "2 1.5" : void 0,
				role: "button",
				tabIndex: 0,
				onClick: () => onTooth(fdi, zone.id),
				onKeyDown: (event) => {
					if (event.key === "Enter" || event.key === " ") {
						event.preventDefault();
						onTooth(fdi, zone.id);
					}
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: `Pieza ${fdi}, ${faceName(fdi, zone.id)}` })
			}, zone.id)),
			tooth.whole === "extraccion" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M6 6 L34 38 M34 6 L6 38",
				className: "mark-line"
			}) : null,
			tooth.whole === "fractura" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 30 16 18 20 26 28 12",
				className: "crack-line"
			}) : null,
			tooth.whole === "endodoncia" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "20",
				cy: "22",
				r: "2.2",
				className: "endo-dot"
			}) : null
		]
	});
}
function Crown({ fdi, tooth, onTooth }) {
	const art = crownPath(toothKind(fdi));
	const upper = isUpper(fdi);
	const absent = tooth.whole === "ausente";
	const fill = crownFill(tooth);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "crown-btn",
		onClick: () => onTooth(fdi, "crown"),
		"aria-label": `Pieza ${fdi}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
			viewBox: "0 0 48 56",
			className: "tooth-svg crown-svg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				transform: upper ? void 0 : "translate(0 56) scale(1 -1)",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: art.body,
						style: { fill },
						className: absent ? "crown-absent" : "crown-body",
						stroke: tooth.whole === "corona" ? "var(--color-corona)" : "var(--color-ink)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: art.grooves,
						className: "grooves"
					}),
					tooth.whole === "extraccion" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M10 12 38 46 M38 12 10 46",
						className: "mark-line"
					}) : null,
					tooth.whole === "fractura" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M14 40 22 24 26 32 36 16",
						className: "crack-line"
					}) : null,
					tooth.whole === "endodoncia" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M24 16 v24",
						className: "endo-line"
					}) : null
				]
			})
		})
	});
}
function crownFill(tooth) {
	if (tooth.whole === "ausente") return "transparent";
	if (tooth.whole && tooth.whole !== "extraccion") return `color-mix(in srgb, ${markColor(tooth.whole)} 72%, white)`;
	const surface = Object.values(tooth.surfaces)[0];
	if (surface) return `color-mix(in srgb, ${markColor(surface)} 58%, white)`;
	return "var(--color-paper)";
}
function faceName(fdi, face) {
	if (face === "v") return "vestibular";
	if (face === "o") return "oclusal";
	if (face === "m") return "mesial";
	if (face === "d") return "distal";
	return isUpper(fdi) ? "palatino" : "lingual";
}
function OrtodonciaSheet({ patient, onEdit }) {
	const paid = sumMoney(patient.controles.map((row) => row.pago));
	const done = patient.controles.filter((row) => row.fecha || row.tratamiento || row.pago).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "sheet",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "orto-head",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkImg, { className: "mark-img lg" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Control de Ortodoncia" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "brand-tag",
					children: "Hoja de control del paciente sobre su caso de ortodoncia."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "orto-fields",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
						label: "Nombre:",
						value: patient.nombreCompleto,
						onChange: (nombreCompleto) => onEdit((p) => ({
							...p,
							nombreCompleto
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
						label: "Fecha instalación superior:",
						value: patient.fechaSup,
						placeholder: "dd/mm/aaaa",
						onChange: (fechaSup) => onEdit((p) => ({
							...p,
							fechaSup
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
						label: "Cuota mensual:",
						value: patient.cuotaMensual,
						inputMode: "decimal",
						placeholder: "S/",
						onChange: (cuotaMensual) => onEdit((p) => ({
							...p,
							cuotaMensual
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
						label: "Fecha instalación inferior:",
						value: patient.fechaInf,
						placeholder: "dd/mm/aaaa",
						onChange: (fechaInf) => onEdit((p) => ({
							...p,
							fechaInf
						}))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "teeth-scroll",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "grid-table warm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Fecha" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "N° de control" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Tratamiento" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Pago mensual" })
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: patient.controles.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
							value: row.fecha,
							label: `Fecha control ${index + 1}`,
							onChange: (fecha) => onEdit((p) => ({
								...p,
								controles: commitRow(p.controles, index, {
									...row,
									fecha,
									nro: row.nro || (fecha ? String(index + 1) : "")
								}, isControlEmpty, blankControl())
							}))
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
							value: row.nro,
							label: `Número de control ${index + 1}`,
							inputMode: "decimal",
							onChange: (nro) => onEdit((p) => ({
								...p,
								controles: commitRow(p.controles, index, {
									...row,
									nro
								}, isControlEmpty, blankControl())
							}))
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
							value: row.tratamiento,
							label: `Tratamiento control ${index + 1}`,
							onChange: (tratamiento) => onEdit((p) => ({
								...p,
								controles: commitRow(p.controles, index, {
									...row,
									tratamiento
								}, isControlEmpty, blankControl())
							}))
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
							value: row.pago,
							label: `Pago control ${index + 1}`,
							inputMode: "decimal",
							onChange: (pago) => onEdit((p) => ({
								...p,
								controles: commitRow(p.controles, index, {
									...row,
									pago
								}, isControlEmpty, blankControl())
							}))
						}) })
					] }, index)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "money-strip no-print",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Controles" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: done })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Cuota" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: patient.cuotaMensual ? formatSoles(sumMoney([patient.cuotaMensual])) : "—" })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Pagado" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: formatSoles(paid) })] })
				]
			})
		]
	});
}
function PlanSheet({ patient, onEdit }) {
	const quoted = sumMoney(patient.presupuesto.map((row) => row.total));
	const paid = sumMoney(patient.planRows.map((row) => row.pago));
	const balance = quoted - paid;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "sheet",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "plan-mast",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "plan-brand",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkImg, { className: "mark-img sm" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "Smile Studio"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Plan de tratamiento" })] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "split-3 plan-id",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
							label: "Paciente:",
							value: patient.nombreCompleto,
							onChange: (nombreCompleto) => onEdit((p) => ({
								...p,
								nombreCompleto
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
							label: "DNI:",
							value: patient.dni,
							inputMode: "numeric",
							onChange: (dni) => onEdit((p) => ({
								...p,
								dni
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperLine, {
							label: "Fecha:",
							value: patient.fecha,
							onChange: (fecha) => onEdit((p) => ({
								...p,
								fecha
							}))
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "plan-top",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Presupuesto" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "teeth-scroll",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "grid-table",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Presupuesto" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Precio unit." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Precio total" })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: patient.presupuesto.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
								value: row.concepto,
								label: `Presupuesto ${index + 1}`,
								onChange: (concepto) => onEdit((p) => ({
									...p,
									presupuesto: commitRow(p.presupuesto, index, {
										...row,
										concepto
									}, isPresupuestoEmpty, blankPresupuesto())
								}))
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
								value: row.unit,
								label: `Precio unitario ${index + 1}`,
								inputMode: "decimal",
								onChange: (unit) => onEdit((p) => ({
									...p,
									presupuesto: commitRow(p.presupuesto, index, {
										...row,
										unit
									}, isPresupuestoEmpty, blankPresupuesto())
								}))
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
								value: row.total,
								label: `Precio total ${index + 1}`,
								inputMode: "decimal",
								onChange: (total) => onEdit((p) => ({
									...p,
									presupuesto: commitRow(p.presupuesto, index, {
										...row,
										total
									}, isPresupuestoEmpty, blankPresupuesto())
								}))
							}) })
						] }, index)) })]
					})
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Evolución" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "teeth-scroll",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "grid-table",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Fecha" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Tratamiento" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Saldo" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Pago" })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: patient.evolucion.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
							["fecha", "Fecha"],
							["tratamiento", "Tratamiento"],
							["saldo", "Saldo"],
							["pago", "Pago"]
						].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
							value: row[key],
							label: `${label} evolución ${index + 1}`,
							inputMode: key === "fecha" || key === "tratamiento" ? "text" : "decimal",
							onChange: (value) => onEdit((p) => ({
								...p,
								evolucion: commitRow(p.evolucion, index, {
									...row,
									[key]: value
								}, isEvolucionEmpty, blankEvolucion())
							}))
						}) }, key)) }, index)) })]
					})
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "plan-bottom",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Plan de tratamiento" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "teeth-scroll",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "grid-table",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Fecha" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Tratamiento" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Pago" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Saldo" })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: patient.planRows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
							[
								"fecha",
								"Fecha",
								"text"
							],
							[
								"tratamiento",
								"Tratamiento",
								"text"
							],
							[
								"pago",
								"Pago",
								"decimal"
							],
							[
								"saldo",
								"Saldo",
								"decimal"
							]
						].map(([key, label, mode]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
							value: row[key],
							label: `${label} plan ${index + 1}`,
							inputMode: mode,
							onChange: (value) => onEdit((p) => ({
								...p,
								planRows: commitRow(p.planRows, index, {
									...row,
									[key]: value
								}, isPlanEmpty, blankPlan())
							}))
						}) }, key)) }, index)) })]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "money-strip no-print",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Presupuesto" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: formatSoles(quoted) })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Cobrado" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: formatSoles(paid) })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Saldo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: formatSoles(balance) })] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hint no-print",
				children: "Los totales salen del precio total del presupuesto y de la columna Pago del plan. Escribe en soles, por ejemplo 150 o 150.50."
			})
		]
	});
}
function ClinicApp() {
	const hydrated = useClinic((s) => s.hydrated);
	(0, import_react.useEffect)(() => {
		Promise.resolve(useClinic.persist.rehydrate()).finally(() => {
			useClinic.getState().setHydrated();
		});
	}, []);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "boot",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioLogo, { className: "studio-logo boot-logo" })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Desk, {});
}
function Desk() {
	const patients = useClinic((s) => s.patients);
	const activeId = useClinic((s) => s.activeId);
	const tab = useClinic((s) => s.tab);
	const tool = useClinic((s) => s.tool);
	const setTab = useClinic((s) => s.setTab);
	const setTool = useClinic((s) => s.setTool);
	const setActive = useClinic((s) => s.setActive);
	const addPatient = useClinic((s) => s.addPatient);
	const removePatient = useClinic((s) => s.removePatient);
	const edit = useClinic((s) => s.edit);
	const applyTooth = useClinic((s) => s.applyTooth);
	const applyArch = useClinic((s) => s.applyArch);
	const copyArch = useClinic((s) => s.copyArch);
	const [query, setQuery] = (0, import_react.useState)("");
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [exporting, setExporting] = (0, import_react.useState)(false);
	const stageRef = (0, import_react.useRef)(null);
	const active = patients.find((p) => p.id === activeId) ?? null;
	const filtered = patients.filter((p) => {
		return `${patientLabel(p)} ${p.dni} ${p.telefono}`.toLowerCase().includes(query.trim().toLowerCase());
	});
	const start = (nextTab) => {
		addPatient(nextTab);
		window.setTimeout(() => document.getElementById("field-paciente")?.focus(), 40);
	};
	const onEdit = (recipe) => {
		if (!active) return;
		edit(active.id, recipe);
	};
	const download = async () => {
		if (!active || exporting) {
			if (!active) setNotice("Abre una ficha para descargar el PDF.");
			return;
		}
		const safe = patientLabel(active).normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9]+/g, "-").replace(/^-|-$/g, "");
		(0, import_react_dom.flushSync)(() => setExporting(true));
		setNotice("Preparando el PDF…");
		try {
			const root = stageRef.current;
			if (!root) throw new Error("sin hoja");
			const { saveSheetsPdf } = await import("./pdf-BXF8-SF2.mjs");
			await saveSheetsPdf(root, `Smile-Studio-${safe || "paciente"}.pdf`);
			setNotice("PDF descargado.");
		} catch {
			setNotice("No se pudo crear el PDF.");
		} finally {
			setExporting(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "desk",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "rail no-print",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rail-brand",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioLogo, { className: "studio-logo side" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn-gold",
						onClick: () => start(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), "Nuevo paciente"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "search",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: query,
							placeholder: "Buscar nombre o DNI",
							onChange: (event) => setQuery(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "patient-list",
						children: filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "empty-list",
							children: "Todavía no hay fichas."
						}) : filtered.map((patient) => {
							const selected = patient.id === active?.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: selected ? "patient on" : "patient",
								onClick: () => {
									setActive(patient.id);
									setPendingDelete(null);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "patient-name",
									children: patientLabel(patient)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "patient-meta",
									children: [patient.dni ? `DNI ${patient.dni}` : "Sin DNI", patient.fecha ? ` · ${patient.fecha}` : ""]
								})]
							}), selected ? pendingDelete === patient.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "confirm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "¿Eliminar esta ficha?" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "text-btn danger",
										onClick: () => removePatient(patient.id),
										children: "Eliminar"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "text-btn",
										onClick: () => setPendingDelete(null),
										children: "Cancelar"
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "text-btn danger",
								onClick: () => setPendingDelete(patient.id),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), "Eliminar ficha"]
							}) : null] }, patient.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rail-foot",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn-line",
							onClick: () => void download(),
							disabled: !active || exporting,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), exporting ? "Descargando…" : "Descargar copia"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Se guarda solo en este dispositivo. Av. Grau 877 · 949 390 316" })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "workspace",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mobile-bar no-print",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkImg, { className: "mark-img sm" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								"aria-label": "Paciente",
								value: active?.id ?? "",
								onChange: (event) => setActive(event.target.value || null),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Sin paciente"
								}), patients.map((patient) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: patient.id,
									children: patientLabel(patient)
								}, patient.id))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn-gold icon-btn",
								onClick: () => start(),
								"aria-label": "Nuevo paciente",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "tabbar no-print",
						role: "tablist",
						"aria-label": "Fichas",
						children: [
							TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								role: "tab",
								"aria-selected": tab === item.id,
								className: tab === item.id ? "tab on" : "tab",
								onClick: () => setTab(item.id),
								children: item.label
							}, item.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "btn-line print-btn",
								onClick: () => window.print(),
								disabled: !active,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4" }), "Imprimir"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "btn-line tab-download",
								onClick: () => void download(),
								disabled: !active || exporting,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), exporting ? "Descargando…" : "PDF"]
							})
						]
					}),
					notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "notice no-print",
						role: "status",
						children: notice
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "desk-scroll",
						children: active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
							tab,
							tool,
							patient: active,
							onTool: setTool,
							onEdit,
							onTooth: (fdi, target) => applyTooth(active.id, fdi, tool, target),
							onArch: (key) => applyArch(active.id, key, tool),
							onCopy: () => copyArch(active.id)
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Welcome, { onStart: start })
					})
				]
			}),
			exporting && active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pdf-stage",
				ref: stageRef,
				"aria-hidden": true,
				children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pdf-page",
					"data-pdf-page": true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
						tab: item.id,
						tool,
						patient: active,
						onTool: setTool,
						onEdit,
						onTooth: (fdi, target) => applyTooth(active.id, fdi, tool, target),
						onArch: (key) => applyArch(active.id, key, tool),
						onCopy: () => copyArch(active.id)
					})
				}, item.id))
			}) : null
		]
	});
}
function Sheet({ tab, tool, patient, onTool, onEdit, onTooth, onArch, onCopy }) {
	if (tab === "ficha") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FichaSheet, {
		patient,
		tool,
		onTool,
		onEdit,
		onArch,
		onCopy
	});
	if (tab === "plan") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanSheet, {
		patient,
		onEdit
	});
	if (tab === "ortodoncia") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrtodonciaSheet, {
		patient,
		onEdit
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OdontogramaSheet, {
		patient,
		tool,
		onTool,
		onEdit,
		onTooth
	});
}
function Welcome({ onStart }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "sheet welcome",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioLogo, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Fichas para atender" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "welcome-copy",
				children: "Cuatro hojas iguales a las del consultorio. Elige una y empieza la ficha del paciente."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "welcome-grid",
				children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "welcome-card",
					onClick: () => onStart(item.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: item.blurb })]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hint",
				children: "Av. Grau 877, Piura · 949 390 316"
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClinicApp, {});
}
//#endregion
export { Home as component };
