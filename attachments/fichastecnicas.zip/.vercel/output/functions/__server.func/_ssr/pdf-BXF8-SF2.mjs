import { t as require_jspdf_node_min } from "../_libs/jspdf.mjs";
import { t as domToPng } from "../_libs/modern-screenshot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pdf-BXF8-SF2.js
var import_jspdf_node_min = require_jspdf_node_min();
var MARGIN = 8;
var PAGE_W = 194;
var PAGE_H = 281;
function loadImage(src) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error("No se pudo leer la hoja."));
		img.src = src;
	});
}
async function waitForImages(root) {
	const imgs = [...root.querySelectorAll("img")];
	await Promise.all(imgs.map(async (img) => {
		if (img.complete && img.naturalWidth > 0) return;
		try {
			await img.decode();
		} catch {
			await new Promise((resolve) => {
				img.addEventListener("load", resolve, { once: true });
				img.addEventListener("error", resolve, { once: true });
			});
		}
	}));
	await document.fonts?.ready;
}
async function saveSheetsPdf(root, filename) {
	await waitForImages(root);
	const pages = [...root.querySelectorAll("[data-pdf-page]")];
	if (!pages.length) throw new Error("No hay hojas para el PDF.");
	const pdf = new import_jspdf_node_min.jsPDF({
		unit: "mm",
		format: "a4",
		orientation: "portrait"
	});
	let started = false;
	for (const page of pages) {
		const img = await loadImage(await domToPng(page, {
			scale: 2,
			backgroundColor: "#FFFDF8",
			width: page.scrollWidth,
			height: page.scrollHeight
		}));
		const pxPerMm = img.width / PAGE_W;
		const slicePx = Math.max(1, Math.floor(PAGE_H * pxPerMm));
		let y = 0;
		while (y < img.height - 1) {
			const sliceH = Math.min(slicePx, img.height - y);
			const canvas = document.createElement("canvas");
			canvas.width = img.width;
			canvas.height = sliceH;
			const ctx = canvas.getContext("2d");
			if (!ctx) throw new Error("No se pudo armar el PDF.");
			ctx.fillStyle = "#FFFDF8";
			ctx.fillRect(0, 0, canvas.width, canvas.height);
			ctx.drawImage(img, 0, y, img.width, sliceH, 0, 0, img.width, sliceH);
			if (started) pdf.addPage();
			started = true;
			pdf.addImage(canvas.toDataURL("image/jpeg", .86), "JPEG", MARGIN, MARGIN, PAGE_W, sliceH / pxPerMm);
			y += sliceH;
		}
	}
	pdf.save(filename);
}
//#endregion
export { saveSheetsPdf };
