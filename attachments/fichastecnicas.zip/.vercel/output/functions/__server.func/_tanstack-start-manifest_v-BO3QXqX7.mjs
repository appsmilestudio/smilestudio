//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BO3QXqX7.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Cu5H_Vhb.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cu5H_Vhb.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BKjgvZa2.js"]
	}
} });
//#endregion
export { tsrStartManifest };
